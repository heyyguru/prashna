<?php
require_once __DIR__ . '/../helpers.php';
require_mentor();
$user = current_user();
$pdo = getDB();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect('/mentor/dashboard.php');

$stmt = $pdo->prepare("SELECT d.*, u.name as student_name, u.phone as student_phone, u.email as student_email FROM doubts d JOIN users u ON d.student_id = u.id WHERE d.id = ?");
$stmt->execute([$id]);
$doubt = $stmt->fetch();

if (!$doubt) {
    set_flash('error', 'Doubt not found.');
    redirect('/mentor/dashboard.php');
}

$rs = $pdo->prepare("SELECT r.*, u.name as mentor_name FROM replies r JOIN users u ON r.mentor_id = u.id WHERE r.doubt_id = ? ORDER BY r.created_at DESC");
$rs->execute([$id]);
$replies = $rs->fetchAll();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { $errors[] = 'Invalid form submission.'; }

    $answer = trim($_POST['answer_text'] ?? '');
    if ($answer === '') $errors[] = 'Answer is required.';

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO replies (doubt_id, mentor_id, answer_text) VALUES (?, ?, ?)");
        $stmt->execute([$id, $user['id'], $answer]);

        if (DB_DRIVER === 'mysql') {
            $pdo->prepare("UPDATE doubts SET status = 'answered', answered_at = NOW() WHERE id = ?")->execute([$id]);
        } else {
            $pdo->prepare("UPDATE doubts SET status = 'answered', answered_at = datetime('now') WHERE id = ?")->execute([$id]);
        }

        sendEmail($doubt['student_email'] ?? '', 'Your doubt has been answered!', "Hi {$doubt['student_name']}, your doubt on '{$doubt['subject']}' has been answered. Login to view the reply.");
        sendSMS($doubt['student_phone'], "Hi {$doubt['student_name']}, your doubt has been answered on HeyyGuru!");

        set_flash('success', 'Reply sent successfully!');
        redirect('/mentor/view_doubt.php?id=' . $id);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Doubt - <?= h(APP_NAME) ?></title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="/" class="brand">
                <img src="/css/logo.jpg" alt="HeyyGuru Logo" class="logo">
                <span><?= h(APP_NAME) ?></span>
            </a>
            <div class="nav-toggle" id="navToggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="nav-overlay" id="navOverlay"></div>
            <div class="nav-links" id="navLinks">
                <a href="/mentor/dashboard.php">Dashboard</a>
                <a href="/logout.php">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1 class="page-title">Doubt #<?= $id ?> <span class="badge badge-<?= $doubt['status'] ?>"><?= h($doubt['status']) ?></span></h1>

        <?php $f = get_flash(); if ($f): ?>
            <div class="alert alert-<?= $f['type'] ?>"><?= h($f['msg']) ?></div>
        <?php endif; ?>

        <div class="student-info">
            <strong>Student:</strong> <?= h($doubt['student_name']) ?> |
            <strong>Phone:</strong> <?= h($doubt['student_phone']) ?>
            <?php if ($doubt['student_email']): ?> | <strong>Email:</strong> <?= h($doubt['student_email']) ?><?php endif; ?>
        </div>

        <div class="card doubt-detail-card">
            <div class="doubt-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; padding-bottom:15px; border-bottom:1px solid var(--border);">
                <span class="badge badge-secondary" style="background:#e7f5ff; color:#1971c2; border:1px solid #a5d8ff;"><?= h($doubt['subject']) ?></span>
                <span class="badge badge-<?= $doubt['status'] ?>"><?= h($doubt['status']) ?></span>
            </div>
            <div class="doubt-content">
                <p style="white-space:pre-wrap; font-size:1.15rem; color:var(--text); line-height:1.6; margin-bottom:20px;"><?= h($doubt['question_text']) ?></p>
                <div class="doubt-footer" style="font-size:0.9rem; color:var(--text-light); background:#f8fafc; padding:15px; border-radius:12px; border:1px solid var(--border);">
                    <strong>Asked by:</strong> <?= h($doubt['student_name']) ?> (<?= h($doubt['student_phone']) ?>)<br>
                    <strong>Date:</strong> <?= h($doubt['created_at']) ?>
                </div>
            </div>
        </div>

        <?php if (!empty($replies)): ?>
            <h2 style="font-size:1.1rem;margin:20px 0 10px;">Replies</h2>
            <?php foreach ($replies as $r): ?>
                <div class="reply-box">
                    <div class="reply-label">Reply by <?= h($r['mentor_name']) ?></div>
                    <p style="white-space:pre-wrap;"><?= h($r['answer_text']) ?></p>
                    <p style="font-size:0.8rem;color:#636E72;margin-top:6px;"><?= h($r['created_at']) ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div class="card">
            <h2 style="font-size:1.1rem;margin-bottom:12px;">Write a Reply</h2>
            <?php foreach ($errors as $e): ?>
                <div class="alert alert-error"><?= h($e) ?></div>
            <?php endforeach; ?>
            <form method="POST">
                <?= csrf_field() ?>
                <div class="form-group">
                    <textarea name="answer_text" required placeholder="Type your answer here..."><?= h($_POST['answer_text'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn btn-success btn-block">Send Reply</button>
            </form>
        </div>

        <div style="margin: 30px 0; text-align: center;">
            <a href="/mentor/dashboard.php" class="btn-outline">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                Back to Dashboard
            </a>
        </div>
    </div>
    <script src="/js/chat.js"></script>
</body>
</html>
